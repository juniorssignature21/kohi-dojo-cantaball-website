/*!
 * sweetalert2 v11.26.24
 * Released under the MIT License.
 */
function e(e, t, n) {
  if ("function" == typeof e ? e === t : e.has(t))
    return arguments.length < 3 ? t : n;
  throw new TypeError("Private element is not present on this object");
}
function t(t, n) {
  return t.get(e(t, n));
}
function n(e, t, n) {
  ((function (e, t) {
    if (t.has(e))
      throw new TypeError(
        "Cannot initialize the same private elements twice on an object",
      );
  })(e, t),
    t.set(e, n));
}
const o = {},
  i = (e) =>
    new Promise((t) => {
      if (!e) return t();
      const n = window.scrollX,
        i = window.scrollY;
      ((o.restoreFocusTimeout = setTimeout(() => {
        (o.previousActiveElement instanceof HTMLElement
          ? (o.previousActiveElement.focus(), (o.previousActiveElement = null))
          : document.body && document.body.focus(),
          t());
      }, 100)),
        window.scrollTo(n, i));
    }),
  s = "swal2-",
  r = [
    "container",
    "shown",
    "height-auto",
    "iosfix",
    "popup",
    "modal",
    "no-backdrop",
    "no-transition",
    "toast",
    "toast-shown",
    "show",
    "hide",
    "close",
    "title",
    "html-container",
    "actions",
    "confirm",
    "deny",
    "cancel",
    "footer",
    "icon",
    "icon-content",
    "image",
    "input",
    "file",
    "range",
    "select",
    "radio",
    "checkbox",
    "label",
    "textarea",
    "inputerror",
    "input-label",
    "validation-message",
    "progress-steps",
    "active-progress-step",
    "progress-step",
    "progress-step-line",
    "loader",
    "loading",
    "styled",
    "top",
    "top-start",
    "top-end",
    "top-left",
    "top-right",
    "center",
    "center-start",
    "center-end",
    "center-left",
    "center-right",
    "bottom",
    "bottom-start",
    "bottom-end",
    "bottom-left",
    "bottom-right",
    "grow-row",
    "grow-column",
    "grow-fullscreen",
    "rtl",
    "timer-progress-bar",
    "timer-progress-bar-container",
    "scrollbar-measure",
    "icon-success",
    "icon-warning",
    "icon-info",
    "icon-question",
    "icon-error",
    "draggable",
    "dragging",
  ].reduce((e, t) => ((e[t] = s + t), e), {}),
  a = ["success", "warning", "info", "question", "error"].reduce(
    (e, t) => ((e[t] = s + t), e),
    {},
  ),
  l = "SweetAlert2:",
  c = (e) => e.charAt(0).toUpperCase() + e.slice(1),
  u = (e) => {
    console.warn(`${l} ${"object" == typeof e ? e.join(" ") : e}`);
  },
  d = (e) => {
    console.error(`${l} ${e}`);
  },
  p = [],
  m = (e, t = null) => {
    var n;
    ((n = `"${e}" is deprecated and will be removed in the next major release.${t ? ` Use "${t}" instead.` : ""}`),
      p.includes(n) || (p.push(n), u(n)));
  },
  g = (e) => ("function" == typeof e ? e() : e),
  h = (e) => e && "function" == typeof e.toPromise,
  f = (e) => (h(e) ? e.toPromise() : Promise.resolve(e)),
  b = (e) => e && Promise.resolve(e) === e,
  y = () => document.body.querySelector(`.${r.container}`),
  v = (e) => {
    const t = y();
    return t ? t.querySelector(e) : null;
  },
  w = (e) => v(`.${e}`),
  C = () => w(r.popup),
  E = () => w(r.icon),
  A = () => w(r.title),
  k = () => w(r["html-container"]),
  B = () => w(r.image),
  $ = () => w(r["progress-steps"]),
  L = () => w(r["validation-message"]),
  P = () => v(`.${r.actions} .${r.confirm}`),
  x = () => v(`.${r.actions} .${r.cancel}`),
  T = () => v(`.${r.actions} .${r.deny}`),
  S = () => v(`.${r.loader}`),
  O = () => w(r.actions),
  M = () => w(r.footer),
  H = () => w(r["timer-progress-bar"]),
  j = () => w(r.close),
  I = () => {
    const e = C();
    if (!e) return [];
    const t = e.querySelectorAll(
        '[tabindex]:not([tabindex="-1"]):not([tabindex="0"])',
      ),
      n = Array.from(t).sort((e, t) => {
        const n = parseInt(e.getAttribute("tabindex") || "0"),
          o = parseInt(t.getAttribute("tabindex") || "0");
        return n > o ? 1 : n < o ? -1 : 0;
      }),
      o = e.querySelectorAll(
        '\n  a[href],\n  area[href],\n  input:not([disabled]),\n  select:not([disabled]),\n  textarea:not([disabled]),\n  button:not([disabled]),\n  iframe,\n  object,\n  embed,\n  [tabindex="0"],\n  [contenteditable],\n  audio[controls],\n  video[controls],\n  summary\n',
      ),
      i = Array.from(o).filter((e) => "-1" !== e.getAttribute("tabindex"));
    return [...new Set(n.concat(i))].filter((e) => ee(e));
  },
  D = () =>
    N(document.body, r.shown) &&
    !N(document.body, r["toast-shown"]) &&
    !N(document.body, r["no-backdrop"]),
  V = () => {
    const e = C();
    return !!e && N(e, r.toast);
  },
  q = (e, t) => {
    if (((e.textContent = ""), t)) {
      const n = new DOMParser().parseFromString(t, "text/html"),
        o = n.querySelector("head");
      o &&
        Array.from(o.childNodes).forEach((t) => {
          e.appendChild(t);
        });
      const i = n.querySelector("body");
      i &&
        Array.from(i.childNodes).forEach((t) => {
          t instanceof HTMLVideoElement || t instanceof HTMLAudioElement
            ? e.appendChild(t.cloneNode(!0))
            : e.appendChild(t);
        });
    }
  },
  N = (e, t) => {
    if (!t) return !1;
    const n = t.split(/\s+/);
    for (let t = 0; t < n.length; t++)
      if (!e.classList.contains(n[t])) return !1;
    return !0;
  },
  _ = (e, t, n) => {
    if (
      (((e, t) => {
        Array.from(e.classList).forEach((n) => {
          Object.values(r).includes(n) ||
            Object.values(a).includes(n) ||
            Object.values(t.showClass || {}).includes(n) ||
            e.classList.remove(n);
        });
      })(e, t),
      !t.customClass)
    )
      return;
    const o = t.customClass[n];
    o &&
      ("string" == typeof o || o.forEach
        ? z(e, o)
        : u(
            `Invalid type of customClass.${n}! Expected string or iterable object, got "${typeof o}"`,
          ));
  },
  F = (e, t) => {
    if (!t) return null;
    switch (t) {
      case "select":
      case "textarea":
      case "file":
        return e.querySelector(`.${r.popup} > .${r[t]}`);
      case "checkbox":
        return e.querySelector(`.${r.popup} > .${r.checkbox} input`);
      case "radio":
        return (
          e.querySelector(`.${r.popup} > .${r.radio} input:checked`) ||
          e.querySelector(`.${r.popup} > .${r.radio} input:first-child`)
        );
      case "range":
        return e.querySelector(`.${r.popup} > .${r.range} input`);
      default:
        return e.querySelector(`.${r.popup} > .${r.input}`);
    }
  },
  R = (e) => {
    if ((e.focus(), "file" !== e.type)) {
      const t = e.value;
      ((e.value = ""), (e.value = t));
    }
  },
  U = (e, t, n) => {
    if (!e || !t) return;
    const o = "string" == typeof t ? t.split(/\s+/).filter(Boolean) : t;
    (Array.isArray(e) ? e : [e]).forEach((e) => {
      o.forEach((t) => {
        n ? e.classList.add(t) : e.classList.remove(t);
      });
    });
  },
  z = (e, t) => {
    U(e, t, !0);
  },
  W = (e, t) => {
    U(e, t, !1);
  },
  K = (e, t) => {
    const n = Array.from(e.children);
    for (let e = 0; e < n.length; e++) {
      const o = n[e];
      if (o instanceof HTMLElement && N(o, t)) return o;
    }
  },
  Y = (e, t, n) => {
    (n === `${parseInt(`${n}`)}` && (n = parseInt(n)),
      n || 0 === n
        ? e.style.setProperty(t, "number" == typeof n ? `${n}px` : n)
        : e.style.removeProperty(t));
  },
  X = (e, t = "flex") => {
    e && (e.style.display = t);
  },
  Z = (e) => {
    e && (e.style.display = "none");
  },
  J = (e, t = "block") => {
    e &&
      new MutationObserver(() => {
        Q(e, e.innerHTML, t);
      }).observe(e, { childList: !0, subtree: !0 });
  },
  G = (e, t, n, o) => {
    const i = e.querySelector(t);
    i && i.style.setProperty(n, o);
  },
  Q = (e, t, n = "flex") => {
    t ? X(e, n) : Z(e);
  },
  ee = (e) =>
    Boolean(
      e && (e.offsetWidth || e.offsetHeight || e.getClientRects().length),
    ),
  te = (e) => Boolean(e.scrollHeight > e.clientHeight),
  ne = (e) => {
    const t = window.getComputedStyle(e),
      n = parseFloat(t.getPropertyValue("animation-duration") || "0"),
      o = parseFloat(t.getPropertyValue("transition-duration") || "0");
    return n > 0 || o > 0;
  },
  oe = (e, t = !1) => {
    const n = H();
    n &&
      ee(n) &&
      (t && ((n.style.transition = "none"), (n.style.width = "100%")),
      setTimeout(() => {
        ((n.style.transition = `width ${e / 1e3}s linear`),
          (n.style.width = "0%"));
      }, 10));
  },
  ie =
    `\n <div aria-labelledby="${r.title}" aria-describedby="${r["html-container"]}" class="${r.popup}" tabindex="-1">\n   <button type="button" class="${r.close}"></button>\n   <ul class="${r["progress-steps"]}"></ul>\n   <div class="${r.icon}"></div>\n   <img class="${r.image}" />\n   <h2 class="${r.title}" id="${r.title}"></h2>\n   <div class="${r["html-container"]}" id="${r["html-container"]}"></div>\n   <input class="${r.input}" id="${r.input}" />\n   <input type="file" class="${r.file}" />\n   <div class="${r.range}">\n     <input type="range" />\n     <output></output>\n   </div>\n   <select class="${r.select}" id="${r.select}"></select>\n   <div class="${r.radio}"></div>\n   <label class="${r.checkbox}">\n     <input type="checkbox" id="${r.checkbox}" />\n     <span class="${r.label}"></span>\n   </label>\n   <textarea class="${r.textarea}" id="${r.textarea}"></textarea>\n   <div class="${r["validation-message"]}" id="${r["validation-message"]}"></div>\n   <div class="${r.actions}">\n     <div class="${r.loader}"></div>\n     <button type="button" class="${r.confirm}"></button>\n     <button type="button" class="${r.deny}"></button>\n     <button type="button" class="${r.cancel}"></button>\n   </div>\n   <div class="${r.footer}"></div>\n   <div class="${r["timer-progress-bar-container"]}">\n     <div class="${r["timer-progress-bar"]}"></div>\n   </div>\n </div>\n`.replace(
      /(^|\n)\s*/g,
      "",
    ),
  se = () => {
    o.currentInstance && o.currentInstance.resetValidationMessage();
  },
  re = (e) => {
    const t = (() => {
      const e = y();
      return (
        !!e &&
        (e.remove(),
        W(
          [document.documentElement, document.body],
          [r["no-backdrop"], r["toast-shown"], r["has-column"]],
        ),
        !0)
      );
    })();
    if ("undefined" == typeof window || "undefined" == typeof document)
      return void d("SweetAlert2 requires document to initialize");
    const n = document.createElement("div");
    ((n.className = r.container),
      t && z(n, r["no-transition"]),
      q(n, ie),
      (n.dataset.swal2Theme = e.theme));
    const i = ((e) => {
      if ("string" == typeof e) {
        const t = document.querySelector(e);
        if (!t) throw new Error(`Target element "${e}" not found`);
        return t;
      }
      return e;
    })(e.target || "body");
    (i.appendChild(n),
      e.topLayer && (n.setAttribute("popover", ""), n.showPopover()),
      ((e) => {
        const t = C();
        t &&
          (t.setAttribute("role", e.toast ? "alert" : "dialog"),
          t.setAttribute("aria-live", e.toast ? "polite" : "assertive"),
          e.toast || t.setAttribute("aria-modal", "true"));
      })(e),
      ((e) => {
        "rtl" === window.getComputedStyle(e).direction &&
          (z(y(), r.rtl), (o.isRTL = !0));
      })(i),
      (() => {
        const e = C();
        if (!e) return;
        const t = K(e, r.input),
          n = K(e, r.file),
          o = e.querySelector(`.${r.range} input`),
          i = e.querySelector(`.${r.range} output`),
          s = K(e, r.select),
          a = e.querySelector(`.${r.checkbox} input`),
          l = K(e, r.textarea);
        (t && (t.oninput = se),
          n && (n.onchange = se),
          s && (s.onchange = se),
          a && (a.onchange = se),
          l && (l.oninput = se),
          o &&
            i &&
            ((o.oninput = () => {
              (se(), (i.value = o.value));
            }),
            (o.onchange = () => {
              (se(), (i.value = o.value));
            })));
      })());
  },
  ae = (e, t) => {
    e instanceof HTMLElement
      ? t.appendChild(e)
      : "object" == typeof e
        ? le(e, t)
        : e && q(t, e);
  },
  le = (e, t) => {
    "jquery" in e ? ce(t, e) : q(t, e.toString());
  },
  ce = (e, t) => {
    if (((e.textContent = ""), 0 in t))
      for (let n = 0; n in t; n++) e.appendChild(t[n].cloneNode(!0));
    else e.appendChild(t.cloneNode(!0));
  },
  ue = (e, t) => {
    const n = O(),
      o = S();
    n &&
      o &&
      (t.showConfirmButton || t.showDenyButton || t.showCancelButton
        ? X(n)
        : Z(n),
      _(n, t, "actions"),
      (function (e, t, n) {
        const o = P(),
          i = T(),
          s = x();
        if (!o || !i || !s) return;
        (de(o, "confirm", n),
          de(i, "deny", n),
          de(s, "cancel", n),
          (function (e, t, n, o) {
            if (!o.buttonsStyling) return void W([e, t, n], r.styled);
            z([e, t, n], r.styled);
            const i = [
              [e, "confirm", o.confirmButtonColor],
              [t, "deny", o.denyButtonColor],
              [n, "cancel", o.cancelButtonColor],
            ];
            i.forEach(([e, t, n]) => {
              (n &&
                e.style.setProperty(`--swal2-${t}-button-background-color`, n),
                (function (e) {
                  const t = window.getComputedStyle(e);
                  if (
                    t.getPropertyValue("--swal2-action-button-focus-box-shadow")
                  )
                    return;
                  const n = t.backgroundColor.replace(
                    /rgba?\((\d+), (\d+), (\d+).*/,
                    "rgba($1, $2, $3, 0.5)",
                  );
                  e.style.setProperty(
                    "--swal2-action-button-focus-box-shadow",
                    t
                      .getPropertyValue("--swal2-outline")
                      .replace(/ rgba\(.*/, ` ${n}`),
                  );
                })(e));
            });
          })(o, i, s, n),
          n.reverseButtons &&
            (n.toast
              ? (e.insertBefore(s, o), e.insertBefore(i, o))
              : (e.insertBefore(s, t),
                e.insertBefore(i, t),
                e.insertBefore(o, t))));
      })(n, o, t),
      q(o, t.loaderHtml || ""),
      _(o, t, "loader"));
  };
function de(e, t, n) {
  const o = c(t);
  (Q(e, n[`show${o}Button`], "inline-block"),
    q(e, n[`${t}ButtonText`] || ""),
    e.setAttribute("aria-label", n[`${t}ButtonAriaLabel`] || ""),
    (e.className = r[t]),
    _(e, n, `${t}Button`));
}
const pe = (e, t) => {
  const n = y();
  n &&
    (!(function (e, t) {
      "string" == typeof t
        ? (e.style.background = t)
        : t || z([document.documentElement, document.body], r["no-backdrop"]);
    })(n, t.backdrop),
    (function (e, t) {
      if (!t) return;
      t in r
        ? z(e, r[t])
        : (u('The "position" parameter is not valid, defaulting to "center"'),
          z(e, r.center));
    })(n, t.position),
    (function (e, t) {
      if (!t) return;
      z(e, r[`grow-${t}`]);
    })(n, t.grow),
    _(n, t, "container"));
};
var me = {
  innerParams: new WeakMap(),
  domCache: new WeakMap(),
  focusedElement: new WeakMap(),
};
const ge = [
    "input",
    "file",
    "range",
    "select",
    "radio",
    "checkbox",
    "textarea",
  ],
  he = (e) => {
    if (!e.input) return;
    if (!Ee[e.input])
      return void d(
        `Unexpected type of input! Expected ${Object.keys(Ee).join(" | ")}, got "${e.input}"`,
      );
    const t = we(e.input);
    if (!t) return;
    const n = Ee[e.input](t, e);
    (X(t),
      e.inputAutoFocus &&
        setTimeout(() => {
          R(n);
        }));
  },
  fe = (e, t) => {
    const n = C();
    if (!n) return;
    const o = F(n, e);
    if (o) {
      ((e) => {
        for (let t = 0; t < e.attributes.length; t++) {
          const n = e.attributes[t].name;
          ["id", "type", "value", "style"].includes(n) || e.removeAttribute(n);
        }
      })(o);
      for (const e in t) o.setAttribute(e, t[e]);
    }
  },
  be = (e) => {
    if (!e.input) return;
    const t = we(e.input);
    t && _(t, e, "input");
  },
  ye = (e, t) => {
    !e.placeholder &&
      t.inputPlaceholder &&
      (e.placeholder = t.inputPlaceholder);
  },
  ve = (e, t, n) => {
    if (n.inputLabel) {
      const o = document.createElement("label"),
        i = r["input-label"];
      (o.setAttribute("for", e.id),
        (o.className = i),
        "object" == typeof n.customClass && z(o, n.customClass.inputLabel),
        (o.innerText = n.inputLabel),
        t.insertAdjacentElement("beforebegin", o));
    }
  },
  we = (e) => {
    const t = C();
    if (t) return K(t, r[e] || r.input);
  },
  Ce = (e, t) => {
    ["string", "number"].includes(typeof t)
      ? (e.value = `${t}`)
      : b(t) ||
        u(
          `Unexpected type of inputValue! Expected "string", "number" or "Promise", got "${typeof t}"`,
        );
  },
  Ee = {};
((Ee.text =
  Ee.email =
  Ee.password =
  Ee.number =
  Ee.tel =
  Ee.url =
  Ee.search =
  Ee.date =
  Ee["datetime-local"] =
  Ee.time =
  Ee.week =
  Ee.month =
    (e, t) => {
      const n = e;
      return (
        Ce(n, t.inputValue),
        ve(n, n, t),
        ye(n, t),
        (n.type = t.input),
        n
      );
    }),
  (Ee.file = (e, t) => {
    const n = e;
    return (ve(n, n, t), ye(n, t), n);
  }),
  (Ee.range = (e, t) => {
    const n = e,
      o = n.querySelector("input"),
      i = n.querySelector("output");
    return (
      o && (Ce(o, t.inputValue), (o.type = t.input), ve(o, e, t)),
      i && Ce(i, t.inputValue),
      e
    );
  }),
  (Ee.select = (e, t) => {
    const n = e;
    if (((n.textContent = ""), t.inputPlaceholder)) {
      const e = document.createElement("option");
      (q(e, t.inputPlaceholder),
        (e.value = ""),
        (e.disabled = !0),
        (e.selected = !0),
        n.appendChild(e));
    }
    return (ve(n, n, t), n);
  }),
  (Ee.radio = (e) => ((e.textContent = ""), e)),
  (Ee.checkbox = (e, t) => {
    const n = C();
    if (!n) throw new Error("Popup not found");
    const o = F(n, "checkbox");
    if (!o) throw new Error("Checkbox input not found");
    ((o.value = "1"), (o.checked = Boolean(t.inputValue)));
    const i = e.querySelector("span");
    if (i) {
      const e = t.inputPlaceholder || t.inputLabel;
      e && q(i, e);
    }
    return o;
  }),
  (Ee.textarea = (e, t) => {
    const n = e;
    (Ce(n, t.inputValue), ye(n, t), ve(n, n, t));
    return (
      setTimeout(() => {
        if ("MutationObserver" in window) {
          const e = C();
          if (!e) return;
          const o = parseInt(window.getComputedStyle(e).width);
          new MutationObserver(() => {
            if (!document.body.contains(n)) return;
            const e =
              n.offsetWidth +
              ((i = n),
              parseInt(window.getComputedStyle(i).marginLeft) +
                parseInt(window.getComputedStyle(i).marginRight));
            var i;
            const s = C();
            s && (e > o ? (s.style.width = `${e}px`) : Y(s, "width", t.width));
          }).observe(n, { attributes: !0, attributeFilter: ["style"] });
        }
      }),
      n
    );
  }));
const Ae = (e, t) => {
    const n = k();
    n &&
      (J(n),
      _(n, t, "htmlContainer"),
      t.html
        ? (ae(t.html, n), X(n, "block"))
        : t.text
          ? ((n.textContent = t.text), X(n, "block"))
          : Z(n),
      ((e, t) => {
        const n = C();
        if (!n) return;
        const o = me.innerParams.get(e),
          i = !o || t.input !== o.input;
        (ge.forEach((e) => {
          const o = K(n, r[e]);
          o && (fe(e, t.inputAttributes), (o.className = r[e]), i && Z(o));
        }),
          t.input && (i && he(t), be(t)));
      })(e, t));
  },
  ke = (e, t) => {
    for (const [n, o] of Object.entries(a)) t.icon !== n && W(e, o);
    (z(e, t.icon && a[t.icon]), Le(e, t), Be(), _(e, t, "icon"));
  },
  Be = () => {
    const e = C();
    if (!e) return;
    const t = window.getComputedStyle(e).getPropertyValue("background-color"),
      n = e.querySelectorAll(
        "[class^=swal2-success-circular-line], .swal2-success-fix",
      );
    for (let e = 0; e < n.length; e++) n[e].style.backgroundColor = t;
  },
  $e = (e, t) => {
    if (!t.icon && !t.iconHtml) return;
    let n = e.innerHTML,
      o = "";
    if (t.iconHtml) o = Pe(t.iconHtml);
    else if ("success" === t.icon)
      ((o = ((e) =>
        `\n  ${e.animation ? '<div class="swal2-success-circular-line-left"></div>' : ""}\n  <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>\n  <div class="swal2-success-ring"></div>\n  ${e.animation ? '<div class="swal2-success-fix"></div>' : ""}\n  ${e.animation ? '<div class="swal2-success-circular-line-right"></div>' : ""}\n`)(
        t,
      )),
        (n = n.replace(/ style=".*?"/g, "")));
    else if ("error" === t.icon)
      o =
        '\n  <span class="swal2-x-mark">\n    <span class="swal2-x-mark-line-left"></span>\n    <span class="swal2-x-mark-line-right"></span>\n  </span>\n';
    else if (t.icon) {
      o = Pe({ question: "?", warning: "!", info: "i" }[t.icon]);
    }
    n.trim() !== o.trim() && q(e, o);
  },
  Le = (e, t) => {
    if (t.iconColor) {
      ((e.style.color = t.iconColor), (e.style.borderColor = t.iconColor));
      for (const n of [
        ".swal2-success-line-tip",
        ".swal2-success-line-long",
        ".swal2-x-mark-line-left",
        ".swal2-x-mark-line-right",
      ])
        G(e, n, "background-color", t.iconColor);
      G(e, ".swal2-success-ring", "border-color", t.iconColor);
    }
  },
  Pe = (e) => `<div class="${r["icon-content"]}">${e}</div>`;
let xe = !1,
  Te = 0,
  Se = 0,
  Oe = 0,
  Me = 0;
const He = (e) => {
    const t = C();
    if (!t) return;
    const n = E();
    if (e.target === t || (n && n.contains(e.target))) {
      xe = !0;
      const n = De(e);
      ((Te = n.clientX),
        (Se = n.clientY),
        (Oe = parseInt(t.style.insetInlineStart) || 0),
        (Me = parseInt(t.style.insetBlockStart) || 0),
        z(t, "swal2-dragging"));
    }
  },
  je = (e) => {
    const t = C();
    if (t && xe) {
      let { clientX: n, clientY: i } = De(e);
      const s = n - Te;
      ((t.style.insetInlineStart = `${Oe + (o.isRTL ? -s : s)}px`),
        (t.style.insetBlockStart = `${Me + (i - Se)}px`));
    }
  },
  Ie = () => {
    const e = C();
    ((xe = !1), W(e, "swal2-dragging"));
  },
  De = (e) => {
    const t = e.type.startsWith("touch") ? e.touches[0] : e;
    return { clientX: t.clientX, clientY: t.clientY };
  },
  Ve = (e, t) => {
    const n = y(),
      o = C();
    if (n && o) {
      if (t.toast) {
        (Y(n, "width", t.width), (o.style.width = "100%"));
        const e = S();
        e && o.insertBefore(e, E());
      } else Y(o, "width", t.width);
      (Y(o, "padding", t.padding),
        t.color && (o.style.color = t.color),
        t.background && (o.style.background = t.background),
        Z(L()),
        qe(o, t),
        t.draggable && !t.toast
          ? (z(o, r.draggable),
            ((e) => {
              (e.addEventListener("mousedown", He),
                document.body.addEventListener("mousemove", je),
                e.addEventListener("mouseup", Ie),
                e.addEventListener("touchstart", He),
                document.body.addEventListener("touchmove", je),
                e.addEventListener("touchend", Ie));
            })(o))
          : (W(o, r.draggable),
            ((e) => {
              (e.removeEventListener("mousedown", He),
                document.body.removeEventListener("mousemove", je),
                e.removeEventListener("mouseup", Ie),
                e.removeEventListener("touchstart", He),
                document.body.removeEventListener("touchmove", je),
                e.removeEventListener("touchend", Ie));
            })(o)));
    }
  },
  qe = (e, t) => {
    const n = t.showClass || {};
    ((e.className = `${r.popup} ${ee(e) ? n.popup : ""}`),
      t.toast
        ? (z([document.documentElement, document.body], r["toast-shown"]),
          z(e, r.toast))
        : z(e, r.modal),
      _(e, t, "popup"),
      "string" == typeof t.customClass && z(e, t.customClass),
      t.icon && z(e, r[`icon-${t.icon}`]));
  },
  Ne = (e) => {
    const t = document.createElement("li");
    return (z(t, r["progress-step"]), q(t, e), t);
  },
  _e = (e) => {
    const t = document.createElement("li");
    return (
      z(t, r["progress-step-line"]),
      e.progressStepsDistance && Y(t, "width", e.progressStepsDistance),
      t
    );
  },
  Fe = (e, t) => {
    var n;
    (Ve(0, t),
      pe(0, t),
      ((e, t) => {
        const n = $();
        if (!n) return;
        const { progressSteps: o, currentProgressStep: i } = t;
        o && 0 !== o.length && void 0 !== i
          ? (X(n),
            (n.textContent = ""),
            i >= o.length &&
              u(
                "Invalid currentProgressStep parameter, it should be less than progressSteps.length (currentProgressStep like JS arrays starts from 0)",
              ),
            o.forEach((e, s) => {
              const a = Ne(e);
              if (
                (n.appendChild(a),
                s === i && z(a, r["active-progress-step"]),
                s !== o.length - 1)
              ) {
                const e = _e(t);
                n.appendChild(e);
              }
            }))
          : Z(n);
      })(0, t),
      ((e, t) => {
        const n = me.innerParams.get(e),
          o = E();
        if (!o) return;
        if (n && t.icon === n.icon) return ($e(o, t), void ke(o, t));
        if (!t.icon && !t.iconHtml) return void Z(o);
        if (t.icon && -1 === Object.keys(a).indexOf(t.icon))
          return (
            d(
              `Unknown icon! Expected "success", "error", "warning", "info" or "question", got "${t.icon}"`,
            ),
            void Z(o)
          );
        (X(o),
          $e(o, t),
          ke(o, t),
          z(o, t.showClass && t.showClass.icon),
          window
            .matchMedia("(prefers-color-scheme: dark)")
            .addEventListener("change", Be));
      })(e, t),
      ((e, t) => {
        const n = B();
        n &&
          (t.imageUrl
            ? (X(n, ""),
              n.setAttribute("src", t.imageUrl),
              n.setAttribute("alt", t.imageAlt || ""),
              Y(n, "width", t.imageWidth),
              Y(n, "height", t.imageHeight),
              (n.className = r.image),
              _(n, t, "image"))
            : Z(n));
      })(0, t),
      ((e, t) => {
        const n = A();
        n &&
          (J(n),
          Q(n, Boolean(t.title || t.titleText), "block"),
          t.title && ae(t.title, n),
          t.titleText && (n.innerText = t.titleText),
          _(n, t, "title"));
      })(0, t),
      ((e, t) => {
        const n = j();
        n &&
          (q(n, t.closeButtonHtml || ""),
          _(n, t, "closeButton"),
          Q(n, t.showCloseButton),
          n.setAttribute("aria-label", t.closeButtonAriaLabel || ""));
      })(0, t),
      Ae(e, t),
      ue(0, t),
      ((e, t) => {
        const n = M();
        n &&
          (J(n),
          Q(n, Boolean(t.footer), "block"),
          t.footer && ae(t.footer, n),
          _(n, t, "footer"));
      })(0, t));
    const i = C();
    ("function" == typeof t.didRender && i && t.didRender(i),
      null === (n = o.eventEmitter) || void 0 === n || n.emit("didRender", i));
  },
  Re = () => {
    var e;
    return null === (e = P()) || void 0 === e ? void 0 : e.click();
  },
  Ue = Object.freeze({
    cancel: "cancel",
    backdrop: "backdrop",
    close: "close",
    esc: "esc",
    timer: "timer",
  }),
  ze = (e) => {
    if (e.keydownTarget && e.keydownHandlerAdded && e.keydownHandler) {
      const t = e.keydownHandler;
      (e.keydownTarget.removeEventListener("keydown", t, {
        capture: e.keydownListenerCapture,
      }),
        (e.keydownHandlerAdded = !1));
    }
  },
  We = (e, t) => {
    var n;
    const o = I();
    return o.length
      ? (-2 === (e += t) && (e = o.length - 1),
        e === o.length ? (e = 0) : -1 === e && (e = o.length - 1),
        o[e].focus(),
        !(
          navigator.userAgent.includes("Firefox") &&
          o[e] instanceof HTMLIFrameElement
        ))
      : (null === (n = C()) || void 0 === n || n.focus(), !0);
  },
  Ke = ["ArrowRight", "ArrowDown"],
  Ye = ["ArrowLeft", "ArrowUp"],
  Xe = (e, t, n) => {
    e &&
      (t.isComposing ||
        229 === t.keyCode ||
        (e.stopKeydownPropagation && t.stopPropagation(),
        "Enter" === t.key
          ? Ze(t, e)
          : "Tab" === t.key
            ? Je(t)
            : [...Ke, ...Ye].includes(t.key)
              ? Ge(t.key)
              : "Escape" === t.key && Qe(t, e, n)));
  },
  Ze = (e, t) => {
    if (!g(t.allowEnterKey)) return;
    const n = C();
    if (!n || !t.input) return;
    const o = F(n, t.input);
    if (
      e.target &&
      o &&
      e.target instanceof HTMLElement &&
      e.target.outerHTML === o.outerHTML
    ) {
      if (["textarea", "file"].includes(t.input)) return;
      (Re(), e.preventDefault());
    }
  },
  Je = (e) => {
    const t = e.target,
      n = I();
    let o = -1;
    for (let e = 0; e < n.length; e++)
      if (t === n[e]) {
        o = e;
        break;
      }
    let i = !0;
    ((i = e.shiftKey ? We(o, -1) : We(o, 1)),
      e.stopPropagation(),
      i && e.preventDefault());
  },
  Ge = (e) => {
    const t = O(),
      n = P(),
      o = T(),
      i = x();
    if (!(t && n && o && i)) return;
    const s = [n, o, i];
    if (
      document.activeElement instanceof HTMLElement &&
      !s.includes(document.activeElement)
    )
      return;
    const r = Ke.includes(e) ? "nextElementSibling" : "previousElementSibling";
    let a = document.activeElement;
    if (a) {
      for (let e = 0; e < t.children.length; e++) {
        if (((a = a[r]), !a)) return;
        if (a instanceof HTMLButtonElement && ee(a)) break;
      }
      a instanceof HTMLButtonElement && a.focus();
    }
  },
  Qe = (e, t, n) => {
    (e.preventDefault(), g(t.allowEscapeKey) && n(Ue.esc));
  };
var et = {
  swalPromiseResolve: new WeakMap(),
  swalPromiseReject: new WeakMap(),
};
const tt = () => {
    Array.from(document.body.children).forEach((e) => {
      e.hasAttribute("data-previous-aria-hidden")
        ? (e.setAttribute(
            "aria-hidden",
            e.getAttribute("data-previous-aria-hidden") || "",
          ),
          e.removeAttribute("data-previous-aria-hidden"))
        : e.removeAttribute("aria-hidden");
    });
  },
  nt = "undefined" != typeof window && Boolean(window.GestureEvent),
  ot = nt && /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream,
  it = () => {
    const e = y();
    if (!e) return;
    let t;
    ((e.ontouchstart = (e) => {
      t = st(e);
    }),
      (e.ontouchmove = (e) => {
        t && (e.preventDefault(), e.stopPropagation());
      }));
  },
  st = (e) => {
    const t = e.target,
      n = y(),
      o = k();
    return (
      !(!n || !o) &&
      !rt(e) &&
      !at(e) &&
      (t === n ||
        !(
          te(n) ||
          !(t instanceof HTMLElement) ||
          ((e, t) => {
            let n = e;
            for (; n && n !== t; ) {
              if (te(n)) return !0;
              n = n.parentElement;
            }
            return !1;
          })(t, o) ||
          "INPUT" === t.tagName ||
          "TEXTAREA" === t.tagName ||
          (te(o) && o.contains(t))
        ))
    );
  },
  rt = (e) =>
    Boolean(
      e.touches && e.touches.length && "stylus" === e.touches[0].touchType,
    ),
  at = (e) => e.touches && e.touches.length > 1;
let lt = null;
const ct = (e) => {
  null === lt &&
    (document.body.scrollHeight > window.innerHeight || "scroll" === e) &&
    ((lt = parseInt(
      window.getComputedStyle(document.body).getPropertyValue("padding-right"),
    )),
    (document.body.style.paddingRight = `${
      lt +
      (() => {
        const e = document.createElement("div");
        ((e.className = r["scrollbar-measure"]), document.body.appendChild(e));
        const t = e.getBoundingClientRect().width - e.clientWidth;
        return (document.body.removeChild(e), t);
      })()
    }px`));
};
function ut(e, t, n, s) {
  (V() ? yt(e, s) : (i(n).then(() => yt(e, s)), ze(o)),
    nt
      ? (t.setAttribute("style", "display:none !important"),
        t.removeAttribute("class"),
        (t.innerHTML = ""))
      : t.remove(),
    D() &&
      (null !== lt &&
        ((document.body.style.paddingRight = `${lt}px`), (lt = null)),
      (() => {
        if (N(document.body, r.iosfix)) {
          const e = parseInt(document.body.style.top, 10);
          (W(document.body, r.iosfix),
            (document.body.style.top = ""),
            (document.body.scrollTop = -1 * e));
        }
      })(),
      tt()),
    W(
      [document.documentElement, document.body],
      [r.shown, r["height-auto"], r["no-backdrop"], r["toast-shown"]],
    ));
}
function dt(e) {
  e = ht(e);
  const t = et.swalPromiseResolve.get(this),
    n = pt(this);
  this.isAwaitingPromise ? e.isDismissed || (gt(this), t(e)) : n && t(e);
}
const pt = (e) => {
  const t = C();
  if (!t) return !1;
  const n = me.innerParams.get(e);
  if (!n || N(t, n.hideClass.popup)) return !1;
  (W(t, n.showClass.popup), z(t, n.hideClass.popup));
  const o = y();
  return (
    W(o, n.showClass.backdrop),
    z(o, n.hideClass.backdrop),
    ft(e, t, n),
    !0
  );
};
function mt(e) {
  const t = et.swalPromiseReject.get(this);
  (gt(this), t && t(e));
}
const gt = (e) => {
    e.isAwaitingPromise &&
      (delete e.isAwaitingPromise, me.innerParams.get(e) || e._destroy());
  },
  ht = (e) =>
    void 0 === e
      ? { isConfirmed: !1, isDenied: !1, isDismissed: !0 }
      : Object.assign({ isConfirmed: !1, isDenied: !1, isDismissed: !1 }, e),
  ft = (e, t, n) => {
    var i;
    const s = y(),
      r = ne(t);
    ("function" == typeof n.willClose && n.willClose(t),
      null === (i = o.eventEmitter) || void 0 === i || i.emit("willClose", t),
      r && s
        ? bt(e, t, s, Boolean(n.returnFocus), n.didClose)
        : s && ut(e, s, Boolean(n.returnFocus), n.didClose));
  },
  bt = (e, t, n, i, s) => {
    o.swalCloseEventFinishedCallback = ut.bind(null, e, n, i, s);
    const r = function (e) {
      var n;
      e.target === t &&
        (null === (n = o.swalCloseEventFinishedCallback) ||
          void 0 === n ||
          n.call(o),
        delete o.swalCloseEventFinishedCallback,
        t.removeEventListener("animationend", r),
        t.removeEventListener("transitionend", r));
    };
    (t.addEventListener("animationend", r),
      t.addEventListener("transitionend", r));
  },
  yt = (e, t) => {
    setTimeout(() => {
      var n;
      ("function" == typeof t && t.bind(e.params)(),
        null === (n = o.eventEmitter) || void 0 === n || n.emit("didClose"),
        e._destroy && e._destroy());
    });
  },
  vt = (e) => {
    let t = C();
    if ((t || new Gn(), (t = C()), !t)) return;
    const n = S();
    (V() ? Z(E()) : wt(t, e),
      X(n),
      t.setAttribute("data-loading", "true"),
      t.setAttribute("aria-busy", "true"),
      t.focus());
  },
  wt = (e, t) => {
    const n = O(),
      o = S();
    n &&
      o &&
      (!t && ee(P()) && (t = P()),
      X(n),
      t &&
        (Z(t),
        o.setAttribute("data-button-to-replace", t.className),
        n.insertBefore(o, t)),
      z([e, n], r.loading));
  },
  Ct = (e) => (e.checked ? 1 : 0),
  Et = (e) => (e.checked ? e.value : null),
  At = (e) =>
    e.files && e.files.length
      ? null !== e.getAttribute("multiple")
        ? e.files
        : e.files[0]
      : null,
  kt = (e, t) => {
    const n = C();
    if (!n) return;
    const o = (e) => {
      "select" === t.input
        ? (function (e, t, n) {
            const o = K(e, r.select);
            if (!o) return;
            const i = (e, t, o) => {
              const i = document.createElement("option");
              ((i.value = o),
                q(i, t),
                (i.selected = Lt(o, n.inputValue)),
                e.appendChild(i));
            };
            (t.forEach((e) => {
              const t = e[0],
                n = e[1];
              if (Array.isArray(n)) {
                const e = document.createElement("optgroup");
                ((e.label = t),
                  (e.disabled = !1),
                  o.appendChild(e),
                  n.forEach((t) => i(e, t[1], t[0])));
              } else i(o, n, t);
            }),
              o.focus());
          })(n, $t(e), t)
        : "radio" === t.input &&
          (function (e, t, n) {
            const o = K(e, r.radio);
            if (!o) return;
            t.forEach((e) => {
              const t = e[0],
                i = e[1],
                s = document.createElement("input"),
                a = document.createElement("label");
              ((s.type = "radio"),
                (s.name = r.radio),
                (s.value = t),
                Lt(t, n.inputValue) && (s.checked = !0));
              const l = document.createElement("span");
              (q(l, i),
                (l.className = r.label),
                a.appendChild(s),
                a.appendChild(l),
                o.appendChild(a));
            });
            const i = o.querySelectorAll("input");
            i.length && i[0].focus();
          })(n, $t(e), t);
    };
    h(t.inputOptions) || b(t.inputOptions)
      ? (vt(P()),
        f(t.inputOptions).then((t) => {
          (e.hideLoading(), o(t));
        }))
      : "object" == typeof t.inputOptions
        ? o(t.inputOptions)
        : d(
            "Unexpected type of inputOptions! Expected object, Map or Promise, got " +
              typeof t.inputOptions,
          );
  },
  Bt = (e, t) => {
    const n = e.getInput();
    n &&
      (Z(n),
      f(t.inputValue)
        .then((o) => {
          ((n.value = "number" === t.input ? `${parseFloat(o) || 0}` : `${o}`),
            X(n),
            n.focus(),
            e.hideLoading());
        })
        .catch((t) => {
          (d(`Error in inputValue promise: ${t}`),
            (n.value = ""),
            X(n),
            n.focus(),
            e.hideLoading());
        }));
  };
const $t = (e) =>
    (e instanceof Map ? Array.from(e) : Object.entries(e)).map(([e, t]) => [
      e,
      "object" == typeof t ? $t(t) : t,
    ]),
  Lt = (e, t) => Boolean(t) && null != t && t.toString() === e.toString(),
  Pt = (e, t) => {
    const n = me.innerParams.get(e);
    if (!n.input)
      return void d(
        `The "input" parameter is needed to be set when using returnInputValueOn${c(t)}`,
      );
    const o = e.getInput(),
      i = ((e, t) => {
        const n = e.getInput();
        if (!n) return null;
        switch (t.input) {
          case "checkbox":
            return Ct(n);
          case "radio":
            return Et(n);
          case "file":
            return At(n);
          default:
            return t.inputAutoTrim ? n.value.trim() : n.value;
        }
      })(e, n);
    n.inputValidator
      ? xt(e, i, t)
      : o && !o.checkValidity()
        ? (e.enableButtons(),
          e.showValidationMessage(n.validationMessage || o.validationMessage))
        : "deny" === t
          ? Tt(e, i)
          : Mt(e, i);
  },
  xt = (e, t, n) => {
    const o = me.innerParams.get(e);
    e.disableInput();
    Promise.resolve()
      .then(() => f(o.inputValidator(t, o.validationMessage)))
      .then((o) => {
        (e.enableButtons(),
          e.enableInput(),
          o ? e.showValidationMessage(o) : "deny" === n ? Tt(e, t) : Mt(e, t));
      });
  },
  Tt = (e, t) => {
    const n = me.innerParams.get(e);
    if ((n.showLoaderOnDeny && vt(T()), n.preDeny)) {
      e.isAwaitingPromise = !0;
      Promise.resolve()
        .then(() => f(n.preDeny(t, n.validationMessage)))
        .then((n) => {
          !1 === n
            ? (e.hideLoading(), gt(e))
            : e.close({ isDenied: !0, value: void 0 === n ? t : n });
        })
        .catch((t) => Ot(e, t));
    } else e.close({ isDenied: !0, value: t });
  },
  St = (e, t) => {
    e.close({ isConfirmed: !0, value: t });
  },
  Ot = (e, t) => {
    e.rejectPromise(t);
  },
  Mt = (e, t) => {
    const n = me.innerParams.get(e);
    if ((n.showLoaderOnConfirm && vt(), n.preConfirm)) {
      (e.resetValidationMessage(), (e.isAwaitingPromise = !0));
      Promise.resolve()
        .then(() => f(n.preConfirm(t, n.validationMessage)))
        .then((n) => {
          ee(L()) || !1 === n
            ? (e.hideLoading(), gt(e))
            : St(e, void 0 === n ? t : n);
        })
        .catch((t) => Ot(e, t));
    } else St(e, t);
  };
function Ht() {
  const e = me.innerParams.get(this);
  if (!e) return;
  const t = me.domCache.get(this);
  (Z(t.loader),
    V() ? e.icon && X(E()) : jt(t),
    W([t.popup, t.actions], r.loading),
    t.popup.removeAttribute("aria-busy"),
    t.popup.removeAttribute("data-loading"),
    (t.confirmButton.disabled = !1),
    (t.denyButton.disabled = !1),
    (t.cancelButton.disabled = !1));
  const n = me.focusedElement.get(this);
  (n instanceof HTMLElement &&
    document.activeElement === document.body &&
    n.focus(),
    me.focusedElement.delete(this));
}
const jt = (e) => {
  const t = e.loader.getAttribute("data-button-to-replace"),
    n = t ? e.popup.getElementsByClassName(t) : [];
  n.length
    ? X(n[0], "inline-block")
    : ee(P()) || ee(T()) || ee(x()) || Z(e.actions);
};
function It() {
  const e = me.innerParams.get(this),
    t = me.domCache.get(this);
  return t ? F(t.popup, e.input) : null;
}
function Dt(e, t, n) {
  const o = me.domCache.get(e);
  t.forEach((e) => {
    o[e].disabled = n;
  });
}
function Vt(e, t) {
  const n = C();
  if (n && e)
    if ("radio" === e.type) {
      const e = n.querySelectorAll(`[name="${r.radio}"]`);
      for (let n = 0; n < e.length; n++) e[n].disabled = t;
    } else e.disabled = t;
}
function qt() {
  Dt(this, ["confirmButton", "denyButton", "cancelButton"], !1);
  const e = me.focusedElement.get(this);
  (e instanceof HTMLElement &&
    document.activeElement === document.body &&
    e.focus(),
    me.focusedElement.delete(this));
}
function Nt() {
  (me.focusedElement.set(this, document.activeElement),
    Dt(this, ["confirmButton", "denyButton", "cancelButton"], !0));
}
function _t() {
  Vt(this.getInput(), !1);
}
function Ft() {
  Vt(this.getInput(), !0);
}
function Rt(e) {
  const t = me.domCache.get(this),
    n = me.innerParams.get(this);
  (q(t.validationMessage, e),
    (t.validationMessage.className = r["validation-message"]),
    n.customClass &&
      n.customClass.validationMessage &&
      z(t.validationMessage, n.customClass.validationMessage),
    X(t.validationMessage));
  const o = this.getInput();
  o &&
    (o.setAttribute("aria-invalid", "true"),
    o.setAttribute("aria-describedby", r["validation-message"]),
    R(o),
    z(o, r.inputerror));
}
function Ut() {
  const e = me.domCache.get(this);
  e.validationMessage && Z(e.validationMessage);
  const t = this.getInput();
  t &&
    (t.removeAttribute("aria-invalid"),
    t.removeAttribute("aria-describedby"),
    W(t, r.inputerror));
}
const zt = {
    title: "",
    titleText: "",
    text: "",
    html: "",
    footer: "",
    icon: void 0,
    iconColor: void 0,
    iconHtml: void 0,
    template: void 0,
    toast: !1,
    draggable: !1,
    animation: !0,
    theme: "light",
    showClass: {
      popup: "swal2-show",
      backdrop: "swal2-backdrop-show",
      icon: "swal2-icon-show",
    },
    hideClass: {
      popup: "swal2-hide",
      backdrop: "swal2-backdrop-hide",
      icon: "swal2-icon-hide",
    },
    customClass: {},
    target: "body",
    color: void 0,
    backdrop: !0,
    heightAuto: !0,
    allowOutsideClick: !0,
    allowEscapeKey: !0,
    allowEnterKey: !0,
    stopKeydownPropagation: !0,
    keydownListenerCapture: !1,
    showConfirmButton: !0,
    showDenyButton: !1,
    showCancelButton: !1,
    preConfirm: void 0,
    preDeny: void 0,
    confirmButtonText: "OK",
    confirmButtonAriaLabel: "",
    confirmButtonColor: void 0,
    denyButtonText: "No",
    denyButtonAriaLabel: "",
    denyButtonColor: void 0,
    cancelButtonText: "Cancel",
    cancelButtonAriaLabel: "",
    cancelButtonColor: void 0,
    buttonsStyling: !0,
    reverseButtons: !1,
    focusConfirm: !0,
    focusDeny: !1,
    focusCancel: !1,
    returnFocus: !0,
    showCloseButton: !1,
    closeButtonHtml: "&times;",
    closeButtonAriaLabel: "Close this dialog",
    loaderHtml: "",
    showLoaderOnConfirm: !1,
    showLoaderOnDeny: !1,
    imageUrl: void 0,
    imageWidth: void 0,
    imageHeight: void 0,
    imageAlt: "",
    timer: void 0,
    timerProgressBar: !1,
    width: void 0,
    padding: void 0,
    background: void 0,
    input: void 0,
    inputPlaceholder: "",
    inputLabel: "",
    inputValue: "",
    inputOptions: {},
    inputAutoFocus: !0,
    inputAutoTrim: !0,
    inputAttributes: {},
    inputValidator: void 0,
    returnInputValueOnDeny: !1,
    validationMessage: void 0,
    grow: !1,
    position: "center",
    progressSteps: [],
    currentProgressStep: void 0,
    progressStepsDistance: void 0,
    willOpen: void 0,
    didOpen: void 0,
    didRender: void 0,
    willClose: void 0,
    didClose: void 0,
    didDestroy: void 0,
    scrollbarPadding: !0,
    topLayer: !1,
  },
  Wt = [
    "allowEscapeKey",
    "allowOutsideClick",
    "background",
    "buttonsStyling",
    "cancelButtonAriaLabel",
    "cancelButtonColor",
    "cancelButtonText",
    "closeButtonAriaLabel",
    "closeButtonHtml",
    "color",
    "confirmButtonAriaLabel",
    "confirmButtonColor",
    "confirmButtonText",
    "currentProgressStep",
    "customClass",
    "denyButtonAriaLabel",
    "denyButtonColor",
    "denyButtonText",
    "didClose",
    "didDestroy",
    "draggable",
    "footer",
    "hideClass",
    "html",
    "icon",
    "iconColor",
    "iconHtml",
    "imageAlt",
    "imageHeight",
    "imageUrl",
    "imageWidth",
    "preConfirm",
    "preDeny",
    "progressSteps",
    "returnFocus",
    "reverseButtons",
    "showCancelButton",
    "showCloseButton",
    "showConfirmButton",
    "showDenyButton",
    "text",
    "title",
    "titleText",
    "theme",
    "willClose",
  ],
  Kt = { allowEnterKey: void 0 },
  Yt = [
    "allowOutsideClick",
    "allowEnterKey",
    "backdrop",
    "draggable",
    "focusConfirm",
    "focusDeny",
    "focusCancel",
    "returnFocus",
    "heightAuto",
    "keydownListenerCapture",
  ],
  Xt = (e) => Object.prototype.hasOwnProperty.call(zt, e),
  Zt = (e) => -1 !== Wt.indexOf(e),
  Jt = (e) => Kt[e],
  Gt = (e) => {
    Xt(e) || u(`Unknown parameter "${e}"`);
  },
  Qt = (e) => {
    Yt.includes(e) && u(`The parameter "${e}" is incompatible with toasts`);
  },
  en = (e) => {
    const t = Jt(e);
    t && m(e, t);
  },
  tn = (e) => {
    (!1 === e.backdrop &&
      e.allowOutsideClick &&
      u(
        '"allowOutsideClick" parameter requires `backdrop` parameter to be set to `true`',
      ),
      e.theme &&
        ![
          "light",
          "dark",
          "auto",
          "minimal",
          "borderless",
          "bootstrap-4",
          "bootstrap-4-light",
          "bootstrap-4-dark",
          "bootstrap-5",
          "bootstrap-5-light",
          "bootstrap-5-dark",
          "material-ui",
          "material-ui-light",
          "material-ui-dark",
          "embed-iframe",
          "bulma",
          "bulma-light",
          "bulma-dark",
        ].includes(e.theme) &&
        u(`Invalid theme "${e.theme}"`));
    for (const t in e) (Gt(t), e.toast && Qt(t), en(t));
  };
function nn(e) {
  const t = y(),
    n = C(),
    o = me.innerParams.get(this);
  if (!n || N(n, o.hideClass.popup))
    return void u(
      "You're trying to update the closed or closing popup, that won't work. Use the update() method in preConfirm parameter or show a new popup.",
    );
  const i = on(e),
    s = Object.assign({}, o, i);
  (tn(s),
    t && (t.dataset.swal2Theme = s.theme),
    Fe(this, s),
    me.innerParams.set(this, s),
    Object.defineProperties(this, {
      params: {
        value: Object.assign({}, this.params, e),
        writable: !1,
        enumerable: !0,
      },
    }));
}
const on = (e) => {
  const t = {};
  return (
    Object.keys(e).forEach((n) => {
      if (Zt(n)) {
        const o = e;
        t[n] = o[n];
      } else u(`Invalid parameter to update: ${n}`);
    }),
    t
  );
};
function sn() {
  var e;
  const t = me.domCache.get(this),
    n = me.innerParams.get(this);
  n
    ? (t.popup &&
        o.swalCloseEventFinishedCallback &&
        (o.swalCloseEventFinishedCallback(),
        delete o.swalCloseEventFinishedCallback),
      "function" == typeof n.didDestroy && n.didDestroy(),
      null === (e = o.eventEmitter) || void 0 === e || e.emit("didDestroy"),
      rn(this))
    : an(this);
}
const rn = (e) => {
    (an(e),
      delete e.params,
      delete o.keydownHandler,
      delete o.keydownTarget,
      delete o.currentInstance);
  },
  an = (e) => {
    e.isAwaitingPromise
      ? (ln(me, e), (e.isAwaitingPromise = !0))
      : (ln(et, e),
        ln(me, e),
        delete e.isAwaitingPromise,
        delete e.disableButtons,
        delete e.enableButtons,
        delete e.getInput,
        delete e.disableInput,
        delete e.enableInput,
        delete e.hideLoading,
        delete e.disableLoading,
        delete e.showValidationMessage,
        delete e.resetValidationMessage,
        delete e.close,
        delete e.closePopup,
        delete e.closeModal,
        delete e.closeToast,
        delete e.rejectPromise,
        delete e.update,
        delete e._destroy);
  },
  ln = (e, t) => {
    for (const n in e) e[n].delete(t);
  };
var cn = Object.freeze({
  __proto__: null,
  _destroy: sn,
  close: dt,
  closeModal: dt,
  closePopup: dt,
  closeToast: dt,
  disableButtons: Nt,
  disableInput: Ft,
  disableLoading: Ht,
  enableButtons: qt,
  enableInput: _t,
  getInput: It,
  handleAwaitingPromise: gt,
  hideLoading: Ht,
  rejectPromise: mt,
  resetValidationMessage: Ut,
  showValidationMessage: Rt,
  update: nn,
});
const un = (e, t, n) => {
    t.popup.onclick = () => {
      (e && (dn(e) || e.timer || e.input)) || n(Ue.close);
    };
  },
  dn = (e) =>
    Boolean(
      e.showConfirmButton ||
      e.showDenyButton ||
      e.showCancelButton ||
      e.showCloseButton,
    );
let pn = !1;
const mn = (e) => {
    e.popup.onmousedown = () => {
      e.container.onmouseup = function (t) {
        ((e.container.onmouseup = () => {}),
          t.target === e.container && (pn = !0));
      };
    };
  },
  gn = (e) => {
    e.container.onmousedown = (t) => {
      (t.target === e.container && t.preventDefault(),
        (e.popup.onmouseup = function (t) {
          ((e.popup.onmouseup = () => {}),
            (t.target === e.popup ||
              (t.target instanceof HTMLElement &&
                e.popup.contains(t.target))) &&
              (pn = !0));
        }));
    };
  },
  hn = (e, t, n) => {
    t.container.onclick = (o) => {
      pn
        ? (pn = !1)
        : o.target === t.container && g(e.allowOutsideClick) && n(Ue.backdrop);
    };
  },
  fn = (e) =>
    e instanceof Element ||
    ((e) => "object" == typeof e && null !== e && "jquery" in e)(e);
const bn = () => {
    if (o.timeout)
      return (
        (() => {
          const e = H();
          if (!e) return;
          const t = parseInt(window.getComputedStyle(e).width);
          (e.style.removeProperty("transition"), (e.style.width = "100%"));
          const n = (t / parseInt(window.getComputedStyle(e).width)) * 100;
          e.style.width = `${n}%`;
        })(),
        o.timeout.stop()
      );
  },
  yn = () => {
    if (o.timeout) {
      const e = o.timeout.start();
      return (oe(e), e);
    }
  };
let vn = !1;
const wn = {};
const Cn = (e) => {
  for (let t = e.target; t && t !== document; t = t.parentNode)
    for (const e in wn) {
      const n = t.getAttribute && t.getAttribute(e);
      if (n) return void wn[e].fire({ template: n });
    }
};
o.eventEmitter = new (class {
  constructor() {
    this.events = {};
  }
  _getHandlersByEventName(e) {
    return (void 0 === this.events[e] && (this.events[e] = []), this.events[e]);
  }
  on(e, t) {
    const n = this._getHandlersByEventName(e);
    n.includes(t) || n.push(t);
  }
  once(e, t) {
    const n = (...o) => {
      (this.removeListener(e, n), t.apply(this, o));
    };
    this.on(e, n);
  }
  emit(e, ...t) {
    this._getHandlersByEventName(e).forEach((e) => {
      try {
        e.apply(this, t);
      } catch (e) {
        console.error(e);
      }
    });
  }
  removeListener(e, t) {
    const n = this._getHandlersByEventName(e),
      o = n.indexOf(t);
    o > -1 && n.splice(o, 1);
  }
  removeAllListeners(e) {
    void 0 !== this.events[e] && (this.events[e].length = 0);
  }
  reset() {
    this.events = {};
  }
})();
var En = Object.freeze({
  __proto__: null,
  argsToParams: (e) => {
    const t = {};
    return (
      "object" != typeof e[0] || fn(e[0])
        ? ["title", "html", "icon"].forEach((n, o) => {
            const i = e[o];
            "string" == typeof i || fn(i)
              ? (t[n] = i)
              : void 0 !== i &&
                d(
                  `Unexpected type of ${n}! Expected "string" or "Element", got ${typeof i}`,
                );
          })
        : Object.assign(t, e[0]),
      t
    );
  },
  bindClickHandler: function (e = "data-swal-template") {
    ((wn[e] = this),
      vn || (document.body.addEventListener("click", Cn), (vn = !0)));
  },
  clickCancel: () => {
    var e;
    return null === (e = x()) || void 0 === e ? void 0 : e.click();
  },
  clickConfirm: Re,
  clickDeny: () => {
    var e;
    return null === (e = T()) || void 0 === e ? void 0 : e.click();
  },
  enableLoading: vt,
  fire: function (...e) {
    return new this(...e);
  },
  getActions: O,
  getCancelButton: x,
  getCloseButton: j,
  getConfirmButton: P,
  getContainer: y,
  getDenyButton: T,
  getFocusableElements: I,
  getFooter: M,
  getHtmlContainer: k,
  getIcon: E,
  getIconContent: () => w(r["icon-content"]),
  getImage: B,
  getInputLabel: () => w(r["input-label"]),
  getLoader: S,
  getPopup: C,
  getProgressSteps: $,
  getTimerLeft: () => o.timeout && o.timeout.getTimerLeft(),
  getTimerProgressBar: H,
  getTitle: A,
  getValidationMessage: L,
  increaseTimer: (e) => {
    if (o.timeout) {
      const t = o.timeout.increase(e);
      return (oe(t, !0), t);
    }
  },
  isDeprecatedParameter: Jt,
  isLoading: () => {
    const e = C();
    return !!e && e.hasAttribute("data-loading");
  },
  isTimerRunning: () => Boolean(o.timeout && o.timeout.isRunning()),
  isUpdatableParameter: Zt,
  isValidParameter: Xt,
  isVisible: () => ee(C()),
  mixin: function (e) {
    return class extends this {
      _main(t, n) {
        return super._main(t, Object.assign({}, e, n));
      }
    };
  },
  off: (e, t) => {
    o.eventEmitter &&
      (e
        ? t
          ? o.eventEmitter.removeListener(e, t)
          : o.eventEmitter.removeAllListeners(e)
        : o.eventEmitter.reset());
  },
  on: (e, t) => {
    o.eventEmitter && o.eventEmitter.on(e, t);
  },
  once: (e, t) => {
    o.eventEmitter && o.eventEmitter.once(e, t);
  },
  resumeTimer: yn,
  showLoading: vt,
  stopTimer: bn,
  toggleTimer: () => {
    const e = o.timeout;
    return e && (e.running ? bn() : yn());
  },
});
class An {
  constructor(e, t) {
    ((this.callback = e),
      (this.remaining = t),
      (this.running = !1),
      this.start());
  }
  start() {
    return (
      this.running ||
        ((this.running = !0),
        (this.started = new Date()),
        (this.id = setTimeout(this.callback, this.remaining))),
      this.remaining
    );
  }
  stop() {
    return (
      this.started &&
        this.running &&
        ((this.running = !1),
        clearTimeout(this.id),
        (this.remaining -= new Date().getTime() - this.started.getTime())),
      this.remaining
    );
  }
  increase(e) {
    const t = this.running;
    return (
      t && this.stop(),
      (this.remaining += e),
      t && this.start(),
      this.remaining
    );
  }
  getTimerLeft() {
    return (this.running && (this.stop(), this.start()), this.remaining);
  }
  isRunning() {
    return this.running;
  }
}
const kn = ["swal-title", "swal-html", "swal-footer"],
  Bn = (e) => {
    const t = {};
    return (
      Array.from(e.querySelectorAll("swal-param")).forEach((e) => {
        Mn(e, ["name", "value"]);
        const n = e.getAttribute("name"),
          o = e.getAttribute("value");
        n &&
          o &&
          (t[n] =
            n in zt && "boolean" == typeof zt[n]
              ? "false" !== o
              : n in zt && "object" == typeof zt[n]
                ? JSON.parse(o)
                : o);
      }),
      t
    );
  },
  $n = (e) => {
    const t = {};
    return (
      Array.from(e.querySelectorAll("swal-function-param")).forEach((e) => {
        const n = e.getAttribute("name"),
          o = e.getAttribute("value");
        n && o && (t[n] = new Function(`return ${o}`)());
      }),
      t
    );
  },
  Ln = (e) => {
    const t = {};
    return (
      Array.from(e.querySelectorAll("swal-button")).forEach((e) => {
        Mn(e, ["type", "color", "aria-label"]);
        const n = e.getAttribute("type");
        if (!n || !["confirm", "cancel", "deny"].includes(n)) return;
        ((t[`${n}ButtonText`] = e.innerHTML), (t[`show${c(n)}Button`] = !0));
        const o = e.getAttribute("color");
        null !== o && (t[`${n}ButtonColor`] = o);
        const i = e.getAttribute("aria-label");
        null !== i && (t[`${n}ButtonAriaLabel`] = i);
      }),
      t
    );
  },
  Pn = (e) => {
    const t = {},
      n = e.querySelector("swal-image");
    if (n) {
      Mn(n, ["src", "width", "height", "alt"]);
      const e = n.getAttribute("src");
      null !== e && (t.imageUrl = e || void 0);
      const o = n.getAttribute("width");
      null !== o && (t.imageWidth = o || void 0);
      const i = n.getAttribute("height");
      null !== i && (t.imageHeight = i || void 0);
      const s = n.getAttribute("alt");
      null !== s && (t.imageAlt = s || void 0);
    }
    return t;
  },
  xn = (e) => {
    const t = {},
      n = e.querySelector("swal-icon");
    return (
      n &&
        (Mn(n, ["type", "color"]),
        n.hasAttribute("type") && (t.icon = n.getAttribute("type")),
        n.hasAttribute("color") && (t.iconColor = n.getAttribute("color")),
        (t.iconHtml = n.innerHTML)),
      t
    );
  },
  Tn = (e) => {
    const t = {},
      n = e.querySelector("swal-input");
    n &&
      (Mn(n, ["type", "label", "placeholder", "value"]),
      (t.input = n.getAttribute("type") || "text"),
      n.hasAttribute("label") && (t.inputLabel = n.getAttribute("label")),
      n.hasAttribute("placeholder") &&
        (t.inputPlaceholder = n.getAttribute("placeholder")),
      n.hasAttribute("value") && (t.inputValue = n.getAttribute("value")));
    const o = Array.from(e.querySelectorAll("swal-input-option"));
    return (
      o.length &&
        ((t.inputOptions = {}),
        o.forEach((e) => {
          Mn(e, ["value"]);
          const n = e.getAttribute("value");
          if (!n) return;
          const o = e.innerHTML;
          t.inputOptions[n] = o;
        })),
      t
    );
  },
  Sn = (e, t) => {
    const n = {};
    for (const o in t) {
      const i = t[o],
        s = e.querySelector(i);
      s && (Mn(s, []), (n[i.replace(/^swal-/, "")] = s.innerHTML.trim()));
    }
    return n;
  },
  On = (e) => {
    const t = kn.concat([
      "swal-param",
      "swal-function-param",
      "swal-button",
      "swal-image",
      "swal-icon",
      "swal-input",
      "swal-input-option",
    ]);
    Array.from(e.children).forEach((e) => {
      const n = e.tagName.toLowerCase();
      t.includes(n) || u(`Unrecognized element <${n}>`);
    });
  },
  Mn = (e, t) => {
    Array.from(e.attributes).forEach((n) => {
      -1 === t.indexOf(n.name) &&
        u([
          `Unrecognized attribute "${n.name}" on <${e.tagName.toLowerCase()}>.`,
          "" +
            (t.length
              ? `Allowed attributes are: ${t.join(", ")}`
              : "To set the value, use HTML within the element."),
        ]);
    });
  },
  Hn = (e) => {
    var t, n;
    const i = y(),
      s = C();
    if (!i || !s) return;
    ("function" == typeof e.willOpen && e.willOpen(s),
      null === (t = o.eventEmitter) || void 0 === t || t.emit("willOpen", s));
    const r = window.getComputedStyle(document.body).overflowY;
    if (
      (Vn(i, s, e),
      setTimeout(() => {
        In(i, s);
      }, 10),
      D() &&
        (Dn(i, void 0 !== e.scrollbarPadding && e.scrollbarPadding, r),
        (() => {
          const e = y();
          Array.from(document.body.children).forEach((t) => {
            t.contains(e) ||
              (t.hasAttribute("aria-hidden") &&
                t.setAttribute(
                  "data-previous-aria-hidden",
                  t.getAttribute("aria-hidden") || "",
                ),
              t.setAttribute("aria-hidden", "true"));
          });
        })()),
      ot &&
        !1 === e.backdrop &&
        s.scrollHeight > i.clientHeight &&
        (i.style.pointerEvents = "auto"),
      V() ||
        o.previousActiveElement ||
        (o.previousActiveElement = document.activeElement),
      "function" == typeof e.didOpen)
    ) {
      const t = e.didOpen;
      setTimeout(() => t(s));
    }
    null === (n = o.eventEmitter) || void 0 === n || n.emit("didOpen", s);
  },
  jn = (e) => {
    const t = C();
    if (!t || e.target !== t) return;
    const n = y();
    n &&
      (t.removeEventListener("animationend", jn),
      t.removeEventListener("transitionend", jn),
      (n.style.overflowY = "auto"),
      W(n, r["no-transition"]));
  },
  In = (e, t) => {
    ne(t)
      ? ((e.style.overflowY = "hidden"),
        t.addEventListener("animationend", jn),
        t.addEventListener("transitionend", jn))
      : (e.style.overflowY = "auto");
  },
  Dn = (e, t, n) => {
    ((() => {
      if (nt && !N(document.body, r.iosfix)) {
        const e = document.body.scrollTop;
        ((document.body.style.top = -1 * e + "px"),
          z(document.body, r.iosfix),
          it());
      }
    })(),
      t && "hidden" !== n && ct(n),
      setTimeout(() => {
        e.scrollTop = 0;
      }));
  },
  Vn = (e, t, n) => {
    var o;
    (null !== (o = n.showClass) &&
      void 0 !== o &&
      o.backdrop &&
      z(e, n.showClass.backdrop),
      n.animation
        ? (t.style.setProperty("opacity", "0", "important"),
          X(t, "grid"),
          setTimeout(() => {
            var e;
            (null !== (e = n.showClass) &&
              void 0 !== e &&
              e.popup &&
              z(t, n.showClass.popup),
              t.style.removeProperty("opacity"));
          }, 10))
        : X(t, "grid"),
      z([document.documentElement, document.body], r.shown),
      n.heightAuto &&
        n.backdrop &&
        !n.toast &&
        z([document.documentElement, document.body], r["height-auto"]));
  };
var qn = (e, t) =>
    /^[a-zA-Z0-9.+_'-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9-]+$/.test(e)
      ? Promise.resolve()
      : Promise.resolve(t || "Invalid email address"),
  Nn = (e, t) =>
    /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-z]{2,63}\b([-a-zA-Z0-9@:%_+.~#?&/=]*)$/.test(
      e,
    )
      ? Promise.resolve()
      : Promise.resolve(t || "Invalid URL");
function _n(e) {
  (!(function (e) {
    e.inputValidator ||
      ("email" === e.input && (e.inputValidator = qn),
      "url" === e.input && (e.inputValidator = Nn));
  })(e),
    e.showLoaderOnConfirm &&
      !e.preConfirm &&
      u(
        "showLoaderOnConfirm is set to true, but preConfirm is not defined.\nshowLoaderOnConfirm should be used together with preConfirm, see usage example:\nhttps://sweetalert2.github.io/#ajax-request",
      ),
    (function (e) {
      (!e.target ||
        ("string" == typeof e.target && !document.querySelector(e.target)) ||
        ("string" != typeof e.target && !e.target.appendChild)) &&
        (u('Target parameter is not valid, defaulting to "body"'),
        (e.target = "body"));
    })(e),
    "string" == typeof e.title &&
      (e.title = e.title.split("\n").join("<br />")),
    re(e));
}
let Fn;
var Rn = new WeakMap();
class Un {
  constructor(...t) {
    if (
      (n(
        this,
        Rn,
        Promise.resolve({ isConfirmed: !1, isDenied: !1, isDismissed: !0 }),
      ),
      "undefined" == typeof window)
    )
      return;
    Fn = this;
    const o = Object.freeze(this.constructor.argsToParams(t));
    var i, s, r;
    ((this.params = o),
      (this.isAwaitingPromise = !1),
      (i = Rn),
      (s = this),
      (r = this._main(Fn.params)),
      i.set(e(i, s), r));
  }
  _main(e, t = {}) {
    if ((tn(Object.assign({}, t, e)), o.currentInstance)) {
      const e = et.swalPromiseResolve.get(o.currentInstance),
        { isAwaitingPromise: t } = o.currentInstance;
      (o.currentInstance._destroy(), t || e({ isDismissed: !0 }), D() && tt());
    }
    o.currentInstance = Fn;
    const n = Wn(e, t);
    (_n(n),
      Object.freeze(n),
      o.timeout && (o.timeout.stop(), delete o.timeout),
      clearTimeout(o.restoreFocusTimeout));
    const i = Kn(Fn);
    return (Fe(Fn, n), me.innerParams.set(Fn, n), zn(Fn, i, n));
  }
  then(e) {
    return t(Rn, this).then(e);
  }
  finally(e) {
    return t(Rn, this).finally(e);
  }
}
const zn = (e, t, n) =>
    new Promise((i, s) => {
      const r = (t) => {
        e.close({ isDismissed: !0, dismiss: t, isConfirmed: !1, isDenied: !1 });
      };
      (et.swalPromiseResolve.set(e, i),
        et.swalPromiseReject.set(e, s),
        (t.confirmButton.onclick = () => {
          ((e) => {
            const t = me.innerParams.get(e);
            (e.disableButtons(), t.input ? Pt(e, "confirm") : Mt(e, !0));
          })(e);
        }),
        (t.denyButton.onclick = () => {
          ((e) => {
            const t = me.innerParams.get(e);
            (e.disableButtons(),
              t.returnInputValueOnDeny ? Pt(e, "deny") : Tt(e, !1));
          })(e);
        }),
        (t.cancelButton.onclick = () => {
          ((e, t) => {
            (e.disableButtons(), t(Ue.cancel));
          })(e, r);
        }),
        (t.closeButton.onclick = () => {
          r(Ue.close);
        }),
        ((e, t, n) => {
          e.toast ? un(e, t, n) : (mn(t), gn(t), hn(e, t, n));
        })(n, t, r),
        ((e, t, n) => {
          if ((ze(e), !t.toast)) {
            const o = (e) => Xe(t, e, n);
            e.keydownHandler = o;
            const i = t.keydownListenerCapture ? window : C();
            if (i) {
              ((e.keydownTarget = i),
                (e.keydownListenerCapture = t.keydownListenerCapture));
              const n = o;
              (e.keydownTarget.addEventListener("keydown", n, {
                capture: e.keydownListenerCapture,
              }),
                (e.keydownHandlerAdded = !0));
            }
          }
        })(o, n, r),
        ((e, t) => {
          "select" === t.input || "radio" === t.input
            ? kt(e, t)
            : ["text", "email", "number", "tel", "textarea"].some(
                (e) => e === t.input,
              ) &&
              (h(t.inputValue) || b(t.inputValue)) &&
              (vt(P()), Bt(e, t));
        })(e, n),
        Hn(n),
        Yn(o, n, r),
        Xn(t, n),
        setTimeout(() => {
          t.container.scrollTop = 0;
        }));
    }),
  Wn = (e, t) => {
    const n = ((e) => {
        const t =
          "string" == typeof e.template
            ? document.querySelector(e.template)
            : e.template;
        if (!t) return {};
        const n = t.content;
        return (
          On(n),
          Object.assign(Bn(n), $n(n), Ln(n), Pn(n), xn(n), Tn(n), Sn(n, kn))
        );
      })(e),
      o = Object.assign({}, zt, t, n, e);
    return (
      (o.showClass = Object.assign({}, zt.showClass, o.showClass)),
      (o.hideClass = Object.assign({}, zt.hideClass, o.hideClass)),
      !1 === o.animation &&
        ((o.showClass = { backdrop: "swal2-noanimation" }), (o.hideClass = {})),
      o
    );
  },
  Kn = (e) => {
    const t = {
      popup: C(),
      container: y(),
      actions: O(),
      confirmButton: P(),
      denyButton: T(),
      cancelButton: x(),
      loader: S(),
      closeButton: j(),
      validationMessage: L(),
      progressSteps: $(),
    };
    return (me.domCache.set(e, t), t);
  },
  Yn = (e, t, n) => {
    const o = H();
    (Z(o),
      t.timer &&
        ((e.timeout = new An(() => {
          (n("timer"), delete e.timeout);
        }, t.timer)),
        t.timerProgressBar &&
          o &&
          (X(o),
          _(o, t, "timerProgressBar"),
          setTimeout(() => {
            e.timeout && e.timeout.running && oe(t.timer);
          }))));
  },
  Xn = (e, t) => {
    if (!t.toast)
      return g(t.allowEnterKey)
        ? void (Zn(e) || Jn(e, t) || We(-1, 1))
        : (m("allowEnterKey", "preConfirm: () => false"), void e.popup.focus());
  },
  Zn = (e) => {
    const t = Array.from(e.popup.querySelectorAll("[autofocus]"));
    for (const e of t)
      if (e instanceof HTMLElement && ee(e)) return (e.focus(), !0);
    return !1;
  },
  Jn = (e, t) =>
    t.focusDeny && ee(e.denyButton)
      ? (e.denyButton.focus(), !0)
      : t.focusCancel && ee(e.cancelButton)
        ? (e.cancelButton.focus(), !0)
        : !(!t.focusConfirm || !ee(e.confirmButton)) &&
          (e.confirmButton.focus(), !0);
((Un.prototype.disableButtons = Nt),
  (Un.prototype.enableButtons = qt),
  (Un.prototype.getInput = It),
  (Un.prototype.disableInput = Ft),
  (Un.prototype.enableInput = _t),
  (Un.prototype.hideLoading = Ht),
  (Un.prototype.disableLoading = Ht),
  (Un.prototype.showValidationMessage = Rt),
  (Un.prototype.resetValidationMessage = Ut),
  (Un.prototype.close = dt),
  (Un.prototype.closePopup = dt),
  (Un.prototype.closeModal = dt),
  (Un.prototype.closeToast = dt),
  (Un.prototype.rejectPromise = mt),
  (Un.prototype.update = nn),
  (Un.prototype._destroy = sn),
  Object.assign(Un, En),
  Object.keys(cn).forEach((e) => {
    Un[e] = function (...t) {
      if (Fn && Fn[e]) return Fn[e](...t);
    };
  }),
  (Un.DismissReason = Ue),
  (Un.version = "11.26.24"));
const Gn = Un;
Gn.default = Gn;
export { Gn as default };
"undefined" != typeof document &&
  (function (e, t) {
    var n = e.createElement("style");
    if ((e.getElementsByTagName("head")[0].appendChild(n), n.styleSheet))
      n.styleSheet.disabled || (n.styleSheet.cssText = t);
    else
      try {
        n.innerHTML = t;
      } catch (e) {
        n.innerText = t;
      }
  })(
    document,
    ':root{--swal2-outline: 0 0 0 3px rgba(100, 150, 200, 0.5);--swal2-container-padding: 0.625em;--swal2-backdrop: rgba(0, 0, 0, 0.4);--swal2-backdrop-transition: background-color 0.15s;--swal2-width: 32em;--swal2-padding: 0 0 1.25em;--swal2-border: none;--swal2-border-radius: 0.3125rem;--swal2-background: white;--swal2-color: #545454;--swal2-show-animation: swal2-show 0.3s;--swal2-hide-animation: swal2-hide 0.15s forwards;--swal2-icon-zoom: 1;--swal2-icon-animations: true;--swal2-title-padding: 0.8em 1em 0;--swal2-html-container-padding: 1em 1.6em 0.3em;--swal2-input-border: 1px solid #d9d9d9;--swal2-input-border-radius: 0.1875em;--swal2-input-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06), 0 0 0 3px transparent;--swal2-input-background: transparent;--swal2-input-transition: border-color 0.2s, box-shadow 0.2s;--swal2-input-hover-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06), 0 0 0 3px transparent;--swal2-input-focus-border: 1px solid #b4dbed;--swal2-input-focus-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06), 0 0 0 3px rgba(100, 150, 200, 0.5);--swal2-progress-step-background: #add8e6;--swal2-validation-message-background: #f0f0f0;--swal2-validation-message-color: #666;--swal2-footer-border-color: #eee;--swal2-footer-background: transparent;--swal2-footer-color: inherit;--swal2-timer-progress-bar-background: rgba(0, 0, 0, 0.3);--swal2-close-button-position: initial;--swal2-close-button-inset: auto;--swal2-close-button-font-size: 2.5em;--swal2-close-button-color: #ccc;--swal2-close-button-transition: color 0.2s, box-shadow 0.2s;--swal2-close-button-outline: initial;--swal2-close-button-box-shadow: inset 0 0 0 3px transparent;--swal2-close-button-focus-box-shadow: inset var(--swal2-outline);--swal2-close-button-hover-transform: none;--swal2-actions-justify-content: center;--swal2-actions-width: auto;--swal2-actions-margin: 1.25em auto 0;--swal2-actions-padding: 0;--swal2-actions-border-radius: 0;--swal2-actions-background: transparent;--swal2-action-button-transition: background-color 0.2s, box-shadow 0.2s;--swal2-action-button-hover: black 10%;--swal2-action-button-active: black 10%;--swal2-confirm-button-box-shadow: none;--swal2-confirm-button-border-radius: 0.25em;--swal2-confirm-button-background-color: #7066e0;--swal2-confirm-button-color: #fff;--swal2-deny-button-box-shadow: none;--swal2-deny-button-border-radius: 0.25em;--swal2-deny-button-background-color: #dc3741;--swal2-deny-button-color: #fff;--swal2-cancel-button-box-shadow: none;--swal2-cancel-button-border-radius: 0.25em;--swal2-cancel-button-background-color: #6e7881;--swal2-cancel-button-color: #fff;--swal2-toast-show-animation: swal2-toast-show 0.5s;--swal2-toast-hide-animation: swal2-toast-hide 0.1s forwards;--swal2-toast-border: none;--swal2-toast-box-shadow: 0 0 1px hsl(0deg 0% 0% / 0.075), 0 1px 2px hsl(0deg 0% 0% / 0.075), 1px 2px 4px hsl(0deg 0% 0% / 0.075), 1px 3px 8px hsl(0deg 0% 0% / 0.075), 2px 4px 16px hsl(0deg 0% 0% / 0.075)}[data-swal2-theme=dark]{--swal2-dark-theme-black: #19191a;--swal2-dark-theme-white: #e1e1e1;--swal2-background: var(--swal2-dark-theme-black);--swal2-color: var(--swal2-dark-theme-white);--swal2-footer-border-color: #555;--swal2-input-background: color-mix(in srgb, var(--swal2-dark-theme-black), var(--swal2-dark-theme-white) 10%);--swal2-validation-message-background: color-mix( in srgb, var(--swal2-dark-theme-black), var(--swal2-dark-theme-white) 10% );--swal2-validation-message-color: var(--swal2-dark-theme-white);--swal2-timer-progress-bar-background: rgba(255, 255, 255, 0.7)}@media(prefers-color-scheme: dark){[data-swal2-theme=auto]{--swal2-dark-theme-black: #19191a;--swal2-dark-theme-white: #e1e1e1;--swal2-background: var(--swal2-dark-theme-black);--swal2-color: var(--swal2-dark-theme-white);--swal2-footer-border-color: #555;--swal2-input-background: color-mix(in srgb, var(--swal2-dark-theme-black), var(--swal2-dark-theme-white) 10%);--swal2-validation-message-background: color-mix( in srgb, var(--swal2-dark-theme-black), var(--swal2-dark-theme-white) 10% );--swal2-validation-message-color: var(--swal2-dark-theme-white);--swal2-timer-progress-bar-background: rgba(255, 255, 255, 0.7)}}body.swal2-shown:not(.swal2-no-backdrop,.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto !important}body.swal2-no-backdrop .swal2-container{background-color:rgba(0,0,0,0) !important;pointer-events:none}body.swal2-no-backdrop .swal2-container .swal2-popup{pointer-events:auto}body.swal2-no-backdrop .swal2-container .swal2-modal{box-shadow:0 0 10px var(--swal2-backdrop)}body.swal2-toast-shown .swal2-container{box-sizing:border-box;width:360px;max-width:100%;background-color:rgba(0,0,0,0);pointer-events:none}body.swal2-toast-shown .swal2-container.swal2-top{inset:0 auto auto 50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{inset:0 0 auto auto}body.swal2-toast-shown .swal2-container.swal2-top-start,body.swal2-toast-shown .swal2-container.swal2-top-left{inset:0 auto auto 0}body.swal2-toast-shown .swal2-container.swal2-center-start,body.swal2-toast-shown .swal2-container.swal2-center-left{inset:50% auto auto 0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{inset:50% auto auto 50%;transform:translate(-50%, -50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{inset:50% 0 auto auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-start,body.swal2-toast-shown .swal2-container.swal2-bottom-left{inset:auto auto 0 0}body.swal2-toast-shown .swal2-container.swal2-bottom{inset:auto auto 0 50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{inset:auto 0 0 auto}@media print{body.swal2-shown:not(.swal2-no-backdrop,.swal2-toast-shown){overflow-y:scroll !important}body.swal2-shown:not(.swal2-no-backdrop,.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop,.swal2-toast-shown) .swal2-container{position:static !important}}div:where(.swal2-container){display:grid;position:fixed;z-index:1060;inset:0;box-sizing:border-box;grid-template-areas:"top-start     top            top-end" "center-start  center         center-end" "bottom-start  bottom-center  bottom-end";grid-template-rows:minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto);height:100%;padding:var(--swal2-container-padding);overflow-x:hidden;transition:var(--swal2-backdrop-transition);-webkit-overflow-scrolling:touch}div:where(.swal2-container).swal2-backdrop-show,div:where(.swal2-container).swal2-noanimation{background:var(--swal2-backdrop)}div:where(.swal2-container).swal2-backdrop-hide{background:rgba(0,0,0,0) !important}div:where(.swal2-container).swal2-top-start,div:where(.swal2-container).swal2-center-start,div:where(.swal2-container).swal2-bottom-start{grid-template-columns:minmax(0, 1fr) auto auto}div:where(.swal2-container).swal2-top,div:where(.swal2-container).swal2-center,div:where(.swal2-container).swal2-bottom{grid-template-columns:auto minmax(0, 1fr) auto}div:where(.swal2-container).swal2-top-end,div:where(.swal2-container).swal2-center-end,div:where(.swal2-container).swal2-bottom-end{grid-template-columns:auto auto minmax(0, 1fr)}div:where(.swal2-container).swal2-top-start>.swal2-popup{align-self:start}div:where(.swal2-container).swal2-top>.swal2-popup{grid-column:2;place-self:start center}div:where(.swal2-container).swal2-top-end>.swal2-popup,div:where(.swal2-container).swal2-top-right>.swal2-popup{grid-column:3;place-self:start end}div:where(.swal2-container).swal2-center-start>.swal2-popup,div:where(.swal2-container).swal2-center-left>.swal2-popup{grid-row:2;align-self:center}div:where(.swal2-container).swal2-center>.swal2-popup{grid-column:2;grid-row:2;place-self:center center}div:where(.swal2-container).swal2-center-end>.swal2-popup,div:where(.swal2-container).swal2-center-right>.swal2-popup{grid-column:3;grid-row:2;place-self:center end}div:where(.swal2-container).swal2-bottom-start>.swal2-popup,div:where(.swal2-container).swal2-bottom-left>.swal2-popup{grid-column:1;grid-row:3;align-self:end}div:where(.swal2-container).swal2-bottom>.swal2-popup{grid-column:2;grid-row:3;place-self:end center}div:where(.swal2-container).swal2-bottom-end>.swal2-popup,div:where(.swal2-container).swal2-bottom-right>.swal2-popup{grid-column:3;grid-row:3;place-self:end end}div:where(.swal2-container).swal2-grow-row>.swal2-popup,div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup{grid-column:1/4;width:100%}div:where(.swal2-container).swal2-grow-column>.swal2-popup,div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup{grid-row:1/4;align-self:stretch}div:where(.swal2-container).swal2-no-transition{transition:none !important}div:where(.swal2-container)[popover]{width:auto;border:0}div:where(.swal2-container) div:where(.swal2-popup){display:none;position:relative;box-sizing:border-box;grid-template-columns:minmax(0, 100%);width:var(--swal2-width);max-width:100%;padding:var(--swal2-padding);border:var(--swal2-border);border-radius:var(--swal2-border-radius);background:var(--swal2-background);color:var(--swal2-color);font-family:inherit;font-size:1rem;container-name:swal2-popup}div:where(.swal2-container) div:where(.swal2-popup):focus{outline:none}div:where(.swal2-container) div:where(.swal2-popup).swal2-loading{overflow-y:hidden}div:where(.swal2-container) div:where(.swal2-popup).swal2-draggable{cursor:grab}div:where(.swal2-container) div:where(.swal2-popup).swal2-draggable div:where(.swal2-icon){cursor:grab}div:where(.swal2-container) div:where(.swal2-popup).swal2-dragging{cursor:grabbing}div:where(.swal2-container) div:where(.swal2-popup).swal2-dragging div:where(.swal2-icon){cursor:grabbing}div:where(.swal2-container) h2:where(.swal2-title){position:relative;max-width:100%;margin:0;padding:var(--swal2-title-padding);color:inherit;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;overflow-wrap:break-word;cursor:initial}div:where(.swal2-container) div:where(.swal2-actions){display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:var(--swal2-actions-justify-content);width:var(--swal2-actions-width);margin:var(--swal2-actions-margin);padding:var(--swal2-actions-padding);border-radius:var(--swal2-actions-border-radius);background:var(--swal2-actions-background)}div:where(.swal2-container) div:where(.swal2-loader){display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 rgba(0,0,0,0) #2778c4 rgba(0,0,0,0)}div:where(.swal2-container) button:where(.swal2-styled){margin:.3125em;padding:.625em 1.1em;transition:var(--swal2-action-button-transition);border:none;box-shadow:0 0 0 3px rgba(0,0,0,0);font-weight:500}div:where(.swal2-container) button:where(.swal2-styled):not([disabled]){cursor:pointer}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-confirm){border-radius:var(--swal2-confirm-button-border-radius);background:initial;background-color:var(--swal2-confirm-button-background-color);box-shadow:var(--swal2-confirm-button-box-shadow);color:var(--swal2-confirm-button-color);font-size:1em}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-confirm):hover{background-color:color-mix(in srgb, var(--swal2-confirm-button-background-color), var(--swal2-action-button-hover))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-confirm):active{background-color:color-mix(in srgb, var(--swal2-confirm-button-background-color), var(--swal2-action-button-active))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-deny){border-radius:var(--swal2-deny-button-border-radius);background:initial;background-color:var(--swal2-deny-button-background-color);box-shadow:var(--swal2-deny-button-box-shadow);color:var(--swal2-deny-button-color);font-size:1em}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-deny):hover{background-color:color-mix(in srgb, var(--swal2-deny-button-background-color), var(--swal2-action-button-hover))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-deny):active{background-color:color-mix(in srgb, var(--swal2-deny-button-background-color), var(--swal2-action-button-active))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-cancel){border-radius:var(--swal2-cancel-button-border-radius);background:initial;background-color:var(--swal2-cancel-button-background-color);box-shadow:var(--swal2-cancel-button-box-shadow);color:var(--swal2-cancel-button-color);font-size:1em}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-cancel):hover{background-color:color-mix(in srgb, var(--swal2-cancel-button-background-color), var(--swal2-action-button-hover))}div:where(.swal2-container) button:where(.swal2-styled):where(.swal2-cancel):active{background-color:color-mix(in srgb, var(--swal2-cancel-button-background-color), var(--swal2-action-button-active))}div:where(.swal2-container) button:where(.swal2-styled):focus-visible{outline:none;box-shadow:var(--swal2-action-button-focus-box-shadow)}div:where(.swal2-container) button:where(.swal2-styled)[disabled]:not(.swal2-loading){opacity:.4}div:where(.swal2-container) button:where(.swal2-styled)::-moz-focus-inner{border:0}div:where(.swal2-container) div:where(.swal2-footer){margin:1em 0 0;padding:1em 1em 0;border-top:1px solid var(--swal2-footer-border-color);background:var(--swal2-footer-background);color:var(--swal2-footer-color);font-size:1em;text-align:center;cursor:initial}div:where(.swal2-container) .swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;grid-column:auto !important;overflow:hidden;border-bottom-right-radius:var(--swal2-border-radius);border-bottom-left-radius:var(--swal2-border-radius)}div:where(.swal2-container) div:where(.swal2-timer-progress-bar){width:100%;height:.25em;background:var(--swal2-timer-progress-bar-background)}div:where(.swal2-container) img:where(.swal2-image){max-width:100%;margin:2em auto 1em;cursor:initial}div:where(.swal2-container) button:where(.swal2-close){position:var(--swal2-close-button-position);inset:var(--swal2-close-button-inset);z-index:2;align-items:center;justify-content:center;width:1.2em;height:1.2em;margin-top:0;margin-right:0;margin-bottom:-1.2em;padding:0;overflow:hidden;transition:var(--swal2-close-button-transition);border:none;border-radius:var(--swal2-border-radius);outline:var(--swal2-close-button-outline);background:rgba(0,0,0,0);color:var(--swal2-close-button-color);font-family:monospace;font-size:var(--swal2-close-button-font-size);cursor:pointer;justify-self:end}div:where(.swal2-container) button:where(.swal2-close):hover{transform:var(--swal2-close-button-hover-transform);background:rgba(0,0,0,0);color:#f27474}div:where(.swal2-container) button:where(.swal2-close):focus-visible{outline:none;box-shadow:var(--swal2-close-button-focus-box-shadow)}div:where(.swal2-container) button:where(.swal2-close)::-moz-focus-inner{border:0}div:where(.swal2-container) div:where(.swal2-html-container){z-index:1;justify-content:center;margin:0;padding:var(--swal2-html-container-padding);overflow:auto;color:inherit;font-size:1.125em;font-weight:normal;line-height:normal;text-align:center;overflow-wrap:break-word;word-break:break-word;cursor:initial}div:where(.swal2-container) input:where(.swal2-input),div:where(.swal2-container) input:where(.swal2-file),div:where(.swal2-container) textarea:where(.swal2-textarea),div:where(.swal2-container) select:where(.swal2-select),div:where(.swal2-container) div:where(.swal2-radio),div:where(.swal2-container) label:where(.swal2-checkbox){margin:1em 2em 3px}div:where(.swal2-container) input:where(.swal2-input),div:where(.swal2-container) input:where(.swal2-file),div:where(.swal2-container) textarea:where(.swal2-textarea){box-sizing:border-box;width:auto;transition:var(--swal2-input-transition);border:var(--swal2-input-border);border-radius:var(--swal2-input-border-radius);background:var(--swal2-input-background);box-shadow:var(--swal2-input-box-shadow);color:inherit;font-size:1.125em}div:where(.swal2-container) input:where(.swal2-input).swal2-inputerror,div:where(.swal2-container) input:where(.swal2-file).swal2-inputerror,div:where(.swal2-container) textarea:where(.swal2-textarea).swal2-inputerror{border-color:#f27474 !important;box-shadow:0 0 2px #f27474 !important}div:where(.swal2-container) input:where(.swal2-input):hover,div:where(.swal2-container) input:where(.swal2-file):hover,div:where(.swal2-container) textarea:where(.swal2-textarea):hover{box-shadow:var(--swal2-input-hover-box-shadow)}div:where(.swal2-container) input:where(.swal2-input):focus,div:where(.swal2-container) input:where(.swal2-file):focus,div:where(.swal2-container) textarea:where(.swal2-textarea):focus{border:var(--swal2-input-focus-border);outline:none;box-shadow:var(--swal2-input-focus-box-shadow)}div:where(.swal2-container) input:where(.swal2-input)::placeholder,div:where(.swal2-container) input:where(.swal2-file)::placeholder,div:where(.swal2-container) textarea:where(.swal2-textarea)::placeholder{color:#ccc}div:where(.swal2-container) .swal2-range{margin:1em 2em 3px;background:var(--swal2-background)}div:where(.swal2-container) .swal2-range input{width:80%}div:where(.swal2-container) .swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}div:where(.swal2-container) .swal2-range input,div:where(.swal2-container) .swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}div:where(.swal2-container) .swal2-input{height:2.625em;padding:0 .75em}div:where(.swal2-container) .swal2-file{width:75%;margin-right:auto;margin-left:auto;background:var(--swal2-input-background);font-size:1.125em}div:where(.swal2-container) .swal2-textarea{height:6.75em;padding:.75em}div:where(.swal2-container) .swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:var(--swal2-input-background);color:inherit;font-size:1.125em}div:where(.swal2-container) .swal2-radio,div:where(.swal2-container) .swal2-checkbox{align-items:center;justify-content:center;background:var(--swal2-background);color:inherit}div:where(.swal2-container) .swal2-radio label,div:where(.swal2-container) .swal2-checkbox label{margin:0 .6em;font-size:1.125em}div:where(.swal2-container) .swal2-radio input,div:where(.swal2-container) .swal2-checkbox input{flex-shrink:0;margin:0 .4em}div:where(.swal2-container) label:where(.swal2-input-label){display:flex;justify-content:center;margin:1em auto 0}div:where(.swal2-container) div:where(.swal2-validation-message){align-items:center;justify-content:center;margin:1em 0 0;padding:.625em;overflow:hidden;background:var(--swal2-validation-message-background);color:var(--swal2-validation-message-color);font-size:1em;font-weight:300}div:where(.swal2-container) div:where(.swal2-validation-message)::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}div:where(.swal2-container) .swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:1.25em auto;padding:0;background:rgba(0,0,0,0);font-weight:600}div:where(.swal2-container) .swal2-progress-steps li{display:inline-block;position:relative}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:var(--swal2-progress-step-background);color:#fff}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:var(--swal2-progress-step-background)}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}div:where(.swal2-icon){position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:2.5em auto .6em;zoom:var(--swal2-icon-zoom);border:.25em solid rgba(0,0,0,0);border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;user-select:none}div:where(.swal2-icon) .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}div:where(.swal2-icon).swal2-error{border-color:#f27474;color:#f27474}div:where(.swal2-icon).swal2-error .swal2-x-mark{position:relative;flex-grow:1}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}@container swal2-popup style(--swal2-icon-animations:true){div:where(.swal2-icon).swal2-error.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-error.swal2-icon-show .swal2-x-mark{animation:swal2-animate-error-x-mark .5s}}div:where(.swal2-icon).swal2-warning{border-color:#f8bb86;color:#f8bb86}@container swal2-popup style(--swal2-icon-animations:true){div:where(.swal2-icon).swal2-warning.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-warning.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .5s}}div:where(.swal2-icon).swal2-info{border-color:#3fc3ee;color:#3fc3ee}@container swal2-popup style(--swal2-icon-animations:true){div:where(.swal2-icon).swal2-info.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-info.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .8s}}div:where(.swal2-icon).swal2-question{border-color:#87adbd;color:#87adbd}@container swal2-popup style(--swal2-icon-animations:true){div:where(.swal2-icon).swal2-question.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-question.swal2-icon-show .swal2-icon-content{animation:swal2-animate-question-mark .8s}}div:where(.swal2-icon).swal2-success{border-color:#a5dc86;color:#a5dc86}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;border-radius:50%}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}div:where(.swal2-icon).swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-0.25em;left:-0.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}div:where(.swal2-icon).swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}@container swal2-popup style(--swal2-icon-animations:true){div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-animate-success-line-tip .75s}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-animate-success-line-long .75s}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-circular-line-right{animation:swal2-rotate-success-circular-line 4.25s ease-in}}[class^=swal2]{-webkit-tap-highlight-color:rgba(0,0,0,0)}.swal2-show{animation:var(--swal2-show-animation)}.swal2-hide{animation:var(--swal2-hide-animation)}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{margin-right:initial;margin-left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}.swal2-toast{box-sizing:border-box;grid-column:1/4 !important;grid-row:1/4 !important;grid-template-columns:min-content auto min-content;padding:1em;overflow-y:hidden;border:var(--swal2-toast-border);background:var(--swal2-background);box-shadow:var(--swal2-toast-box-shadow);pointer-events:auto}.swal2-toast>*{grid-column:2}.swal2-toast h2:where(.swal2-title){margin:.5em 1em;padding:0;font-size:1em;text-align:initial}.swal2-toast .swal2-loading{justify-content:center}.swal2-toast input:where(.swal2-input){height:2em;margin:.5em;font-size:1em}.swal2-toast .swal2-validation-message{font-size:1em}.swal2-toast div:where(.swal2-footer){margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-toast button:where(.swal2-close){grid-column:3/3;grid-row:1/99;align-self:center;width:.8em;height:.8em;margin:0;font-size:2em}.swal2-toast div:where(.swal2-html-container){margin:.5em 1em;padding:0;overflow:initial;font-size:1em;text-align:initial}.swal2-toast div:where(.swal2-html-container):empty{padding:0}.swal2-toast .swal2-loader{grid-column:1;grid-row:1/99;align-self:center;width:2em;height:2em;margin:.25em}.swal2-toast .swal2-icon{grid-column:1;grid-row:1/99;align-self:center;width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:bold}.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-toast div:where(.swal2-actions){justify-content:flex-start;height:auto;margin:0;margin-top:.5em;padding:0 .5em}.swal2-toast button:where(.swal2-styled){margin:.25em .5em;padding:.4em .6em;font-size:1em}.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;border-radius:50%}.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.8em;left:-0.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}@container swal2-popup style(--swal2-icon-animations:true){.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-toast-animate-success-line-tip .75s}.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-toast-animate-success-line-long .75s}}.swal2-toast.swal2-show{animation:var(--swal2-toast-show-animation)}.swal2-toast.swal2-hide{animation:var(--swal2-toast-hide-animation)}@keyframes swal2-show{0%{transform:translate3d(0, -50px, 0) scale(0.9);opacity:0}100%{transform:translate3d(0, 0, 0) scale(1);opacity:1}}@keyframes swal2-hide{0%{transform:translate3d(0, 0, 0) scale(1);opacity:1}100%{transform:translate3d(0, -50px, 0) scale(0.9);opacity:0}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-0.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(0.4);opacity:0}50%{margin-top:1.625em;transform:scale(0.4);opacity:0}80%{margin-top:-0.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0deg);opacity:1}}@keyframes swal2-rotate-loading{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}@keyframes swal2-animate-question-mark{0%{transform:rotateY(-360deg)}100%{transform:rotateY(0)}}@keyframes swal2-animate-i-mark{0%{transform:rotateZ(45deg);opacity:0}25%{transform:rotateZ(-25deg);opacity:.4}50%{transform:rotateZ(15deg);opacity:.8}75%{transform:rotateZ(-5deg);opacity:1}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-toast-show{0%{transform:translateY(-0.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(0.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0deg)}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-0.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}',
  );
